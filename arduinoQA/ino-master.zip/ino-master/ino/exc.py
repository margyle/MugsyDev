# -*- coding: utf-8; -*-

class Abort(Exception):
    pass
